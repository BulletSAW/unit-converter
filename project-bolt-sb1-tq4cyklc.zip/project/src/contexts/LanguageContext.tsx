import React, { createContext, useContext, useState } from 'react';

type Language = 'de' | 'en' | 'es' | 'zh';

type Translations = {
  [key in Language]: {
    [key: string]: string;
  };
};

const translations: Translations = {
  de: {
    title: 'Einheitenumrechner',
    value: 'Wert',
    from: 'Von',
    to: 'Zu',
    convert: 'Umrechnen',
    loading: 'Lade aktuelle Wechselkurse...',
    error: 'Fehler beim Laden der Wechselkurse',
    liveRates: 'Wechselkurse werden in Echtzeit aktualisiert',
    enterValue: 'Geben Sie einen Wert ein',
    year: 'Jahr',
    currency: 'Währung',
    selectCurrency: 'Währung auswählen',
    // Categories
    length: 'Länge',
    temperature: 'Temperatur',
    weight: 'Gewicht',
    time: 'Zeit',
    area: 'Fläche',
    volume: 'Volumen',
    power: 'Leistung',
    // Units - Length
    meter: 'Meter',
    kilometer: 'Kilometer',
    centimeter: 'Zentimeter',
    millimeter: 'Millimeter',
    mile: 'Meilen',
    foot: 'Fuß',
    inch: 'Zoll',
    // Units - Temperature
    celsius: 'Celsius',
    fahrenheit: 'Fahrenheit',
    kelvin: 'Kelvin',
    // Units - Weight
    kilogram: 'Kilogramm',
    gram: 'Gramm',
    milligram: 'Milligramm',
    pound: 'Pfund',
    ounce: 'Unze',
    // Units - Time
    second: 'Sekunden',
    minute: 'Minuten',
    hour: 'Stunden',
    day: 'Tage',
    week: 'Wochen',
    // Units - Area
    squareMeter: 'Quadratmeter',
    squareKilometer: 'Quadratkilometer',
    hectare: 'Hektar',
    are: 'Ar',
    squareFoot: 'Quadratfuß',
    // Units - Volume
    liter: 'Liter',
    milliliter: 'Milliliter',
    cubicMeter: 'Kubikmeter',
    gallon: 'Gallonen',
    cubicFoot: 'Kubikfuß',
    // Units - Power
    watt: 'Watt',
    kilowatt: 'Kilowatt',
    horsepower: 'PS',
    btu: 'BTU/h',
    // Investment Calculator
    investmentCalculator: 'Investment Rechner',
    initialInvestment: 'Anfangsinvestition',
    monthlyContribution: 'Monatlicher Beitrag',
    annualReturn: 'Jährliche Rendite (%)',
    investmentDuration: 'Anlagedauer (Jahre)',
    calculate: 'Berechnen',
    finalAmount: 'Endbetrag',
    totalContributions: 'Gesamteinzahlungen',
    returns: 'Rendite',
    disclaimer: 'Die Berechnungen basieren auf einer vereinfachten Zinseszins-Formel und dienen nur zur Orientierung.',
  },
  en: {
    title: 'Unit Converter',
    value: 'Value',
    from: 'From',
    to: 'To',
    convert: 'Convert',
    loading: 'Loading current exchange rates...',
    error: 'Error loading exchange rates',
    liveRates: 'Exchange rates are updated in real-time',
    enterValue: 'Enter a value',
    year: 'Year',
    currency: 'Currency',
    selectCurrency: 'Select Currency',
    // Categories
    length: 'Length',
    temperature: 'Temperature',
    weight: 'Weight',
    time: 'Time',
    area: 'Area',
    volume: 'Volume',
    power: 'Power',
    // Units - Length
    meter: 'Meters',
    kilometer: 'Kilometers',
    centimeter: 'Centimeters',
    millimeter: 'Millimeters',
    mile: 'Miles',
    foot: 'Feet',
    inch: 'Inches',
    // Units - Temperature
    celsius: 'Celsius',
    fahrenheit: 'Fahrenheit',
    kelvin: 'Kelvin',
    // Units - Weight
    kilogram: 'Kilograms',
    gram: 'Grams',
    milligram: 'Milligrams',
    pound: 'Pounds',
    ounce: 'Ounces',
    // Units - Time
    second: 'Seconds',
    minute: 'Minutes',
    hour: 'Hours',
    day: 'Days',
    week: 'Weeks',
    // Units - Area
    squareMeter: 'Square Meters',
    squareKilometer: 'Square Kilometers',
    hectare: 'Hectares',
    are: 'Ares',
    squareFoot: 'Square Feet',
    // Units - Volume
    liter: 'Liters',
    milliliter: 'Milliliters',
    cubicMeter: 'Cubic Meters',
    gallon: 'Gallons',
    cubicFoot: 'Cubic Feet',
    // Units - Power
    watt: 'Watts',
    kilowatt: 'Kilowatts',
    horsepower: 'Horsepower',
    btu: 'BTU/h',
    // Investment Calculator
    investmentCalculator: 'Investment Calculator',
    initialInvestment: 'Initial Investment',
    monthlyContribution: 'Monthly Contribution',
    annualReturn: 'Annual Return (%)',
    investmentDuration: 'Investment Duration (Years)',
    calculate: 'Calculate',
    finalAmount: 'Final Amount',
    totalContributions: 'Total Contributions',
    returns: 'Returns',
    disclaimer: 'Calculations are based on a simplified compound interest formula and are for guidance only.',
  },
  es: {
    title: 'Conversor de Unidades',
    value: 'Valor',
    from: 'De',
    to: 'A',
    convert: 'Convertir',
    loading: 'Cargando tipos de cambio actuales...',
    error: 'Error al cargar los tipos de cambio',
    liveRates: 'Los tipos de cambio se actualizan en tiempo real',
    enterValue: 'Ingrese un valor',
    year: 'Año',
    currency: 'Moneda',
    selectCurrency: 'Seleccionar Moneda',
    // Categories
    length: 'Longitud',
    temperature: 'Temperatura',
    weight: 'Peso',
    time: 'Tiempo',
    area: 'Área',
    volume: 'Volumen',
    power: 'Potencia',
    // Units - Length
    meter: 'Metros',
    kilometer: 'Kilómetros',
    centimeter: 'Centímetros',
    millimeter: 'Milímetros',
    mile: 'Millas',
    foot: 'Pies',
    inch: 'Pulgadas',
    // Units - Temperature
    celsius: 'Celsius',
    fahrenheit: 'Fahrenheit',
    kelvin: 'Kelvin',
    // Units - Weight
    kilogram: 'Kilogramos',
    gram: 'Gramos',
    milligram: 'Miligramos',
    pound: 'Libras',
    ounce: 'Onzas',
    // Units - Time
    second: 'Segundos',
    minute: 'Minutos',
    hour: 'Horas',
    day: 'Días',
    week: 'Semanas',
    // Units - Area
    squareMeter: 'Metros Cuadrados',
    squareKilometer: 'Kilómetros Cuadrados',
    hectare: 'Hectáreas',
    are: 'Áreas',
    squareFoot: 'Pies Cuadrados',
    // Units - Volume
    liter: 'Litros',
    milliliter: 'Mililitros',
    cubicMeter: 'Metros Cúbicos',
    gallon: 'Galones',
    cubicFoot: 'Pies Cúbicos',
    // Units - Power
    watt: 'Vatios',
    kilowatt: 'Kilovatios',
    horsepower: 'Caballos de Fuerza',
    btu: 'BTU/h',
    // Investment Calculator
    investmentCalculator: 'Calculadora de Inversiones',
    initialInvestment: 'Inversión Inicial',
    monthlyContribution: 'Contribución Mensual',
    annualReturn: 'Rendimiento Anual (%)',
    investmentDuration: 'Duración de la Inversión (Años)',
    calculate: 'Calcular',
    finalAmount: 'Monto Final',
    totalContributions: 'Contribuciones Totales',
    returns: 'Rendimientos',
    disclaimer: 'Los cálculos se basan en una fórmula simplificada de interés compuesto y son solo orientativos.',
  },
  zh: {
    title: '单位转换器',
    value: '数值',
    from: '从',
    to: '到',
    convert: '转换',
    loading: '正在加载当前汇率...',
    error: '加载汇率时出错',
    liveRates: '汇率实时更新',
    enterValue: '请输入数值',
    year: '年',
    currency: '货币',
    selectCurrency: '选择货币',
    // Categories
    length: '长度',
    temperature: '温度',
    weight: '重量',
    time: '时间',
    area: '面积',
    volume: '体积',
    power: '功率',
    // Units - Length
    meter: '米',
    kilometer: '千米',
    centimeter: '厘米',
    millimeter: '毫米',
    mile: '英里',
    foot: '英尺',
    inch: '英寸',
    // Units - Temperature
    celsius: '摄氏度',
    fahrenheit: '华氏度',
    kelvin: '开尔文',
    // Units - Weight
    kilogram: '千克',
    gram: '克',
    milligram: '毫克',
    pound: '磅',
    ounce: '盎司',
    // Units - Time
    second: '秒',
    minute: '分钟',
    hour: '小时',
    day: '天',
    week: '周',
    // Units - Area
    squareMeter: '平方米',
    squareKilometer: '平方千米',
    hectare: '公顷',
    are: '公亩',
    squareFoot: '平方英尺',
    // Units - Volume
    liter: '升',
    milliliter: '毫升',
    cubicMeter: '立方米',
    gallon: '加仑',
    cubicFoot: '立方英尺',
    // Units - Power
    watt: '瓦特',
    kilowatt: '千瓦',
    horsepower: '马力',
    btu: 'BTU/小时',
    // Investment Calculator
    investmentCalculator: '投资计算器',
    initialInvestment: '初始投资',
    monthlyContribution: '每月投入',
    annualReturn: '年回报率 (%)',
    investmentDuration: '投资期限 (年)',
    calculate: '计算',
    finalAmount: '最终金额',
    totalContributions: '总投入',
    returns: '回报',
    disclaimer: '计算基于简化的复利公式，仅供参考。',
  },
};

type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('de');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}