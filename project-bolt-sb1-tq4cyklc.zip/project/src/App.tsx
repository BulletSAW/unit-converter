import React, { useState, useEffect, useMemo } from 'react';
import { ArrowRightLeft, Ruler, Thermometer, Scale, Clock, Calculator, DollarSign, Droplets, Power, TrendingUp, Percent } from 'lucide-react';
import { useLanguage } from './contexts/LanguageContext';
import { LanguageSelector } from './components/LanguageSelector';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

type Category = {
  id: string;
  name: string;
  icon: React.ReactNode;
  units: { id: string; name: string }[];
  convert: (value: number, from: string, to: string, rates?: { [key: string]: number }) => number;
};

const CURRENCIES = [
  'EUR', 'USD', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD', 'CNY', 'INR', 'NZD', 
  'SGD', 'HKD', 'RUB', 'AED'
] as const;

type Currency = typeof CURRENCIES[number];

function InvestmentCalculator() {
  const { t } = useLanguage();
  const [initialInvestment, setInitialInvestment] = useState<string>('');
  const [monthlyContribution, setMonthlyContribution] = useState<string>('');
  const [annualReturn, setAnnualReturn] = useState<string>('');
  const [years, setYears] = useState<string>('');
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>('EUR');
  const [exchangeRates, setExchangeRates] = useState<{ [key: string]: number } | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<{
    finalAmount: number;
    totalContributions: number;
    totalEarnings: number;
    yearlyData: {
      year: number;
      totalAmount: number;
      contributions: number;
      earnings: number;
    }[];
  } | null>(null);

  useEffect(() => {
    const fetchExchangeRates = async () => {
      setLoading(true);
      try {
        const response = await fetch('https://open.er-api.com/v6/latest/EUR');
        const data = await response.json();
        if (data.rates) {
          setExchangeRates(data.rates);
        }
      } catch (err) {
        console.error('Error fetching exchange rates:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchExchangeRates();
  }, []);

  const calculateInvestment = () => {
    const rate = exchangeRates?.[selectedCurrency] || 1;
    const initial = parseFloat(initialInvestment) || 0;
    const monthly = parseFloat(monthlyContribution) || 0;
    const returnRate = (parseFloat(annualReturn) || 0) / 100;
    const numYears = parseFloat(years) || 0;
    const yearlyData = [];

    let totalAmount = initial;
    let totalContributions = initial;
    let previousAmount = initial;

    for (let year = 1; year <= numYears; year++) {
      const yearlyContribution = monthly * 12;
      totalContributions += yearlyContribution;
      totalAmount = (previousAmount + yearlyContribution) * (1 + returnRate);
      
      yearlyData.push({
        year,
        totalAmount: totalAmount * rate,
        contributions: totalContributions * rate,
        earnings: (totalAmount - totalContributions) * rate
      });

      previousAmount = totalAmount;
    }

    setResult({
      finalAmount: totalAmount * rate,
      totalContributions: totalContributions * rate,
      totalEarnings: (totalAmount - totalContributions) * rate,
      yearlyData
    });
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: false
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value: number) => 
            new Intl.NumberFormat('de-DE', { 
              style: 'currency', 
              currency: selectedCurrency,
              maximumFractionDigits: 0
            }).format(value)
        }
      }
    }
  };

  const chartData = result ? {
    labels: result.yearlyData.map(data => `${t('year')} ${data.year}`),
    datasets: [
      {
        label: t('totalAmount'),
        data: result.yearlyData.map(data => data.totalAmount),
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
      },
      {
        label: t('totalContributions'),
        data: result.yearlyData.map(data => data.contributions),
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.5)',
      },
      {
        label: t('returns'),
        data: result.yearlyData.map(data => data.earnings),
        borderColor: 'rgb(168, 85, 247)',
        backgroundColor: 'rgba(168, 85, 247, 0.5)',
      }
    ]
  } : null;

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mt-8">
      <div className="flex items-center justify-center mb-6">
        <TrendingUp className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">{t('investmentCalculator')}</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('currency')}
          </label>
          <select
            value={selectedCurrency}
            onChange={(e) => setSelectedCurrency(e.target.value as Currency)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {CURRENCIES.map((currency) => (
              <option key={currency} value={currency}>
                {currency}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('initialInvestment')} ({selectedCurrency})
          </label>
          <input
            type="number"
            value={initialInvestment}
            onChange={(e) => setInitialInvestment(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="z.B. 10000"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('monthlyContribution')} ({selectedCurrency})
          </label>
          <input
            type="number"
            value={monthlyContribution}
            onChange={(e) => setMonthlyContribution(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="z.B. 500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('annualReturn')}
          </label>
          <input
            type="number"
            value={annualReturn}
            onChange={(e) => setAnnualReturn(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="z.B. 7"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t('investmentDuration')}
          </label>
          <input
            type="number"
            value={years}
            onChange={(e) => setYears(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="z.B. 30"
          />
        </div>
      </div>

      <div className="mt-6 flex justify-center">
        <button
          onClick={calculateInvestment}
          disabled={loading}
          className={`flex items-center px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors ${
            loading ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          <Calculator className="w-5 h-5 mr-2" />
          {t('calculate')}
        </button>
      </div>

      {result && (
        <>
          <div className="mt-8 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">{t('finalAmount')}</h3>
                <p className="text-2xl font-bold text-blue-600">
                  {result.finalAmount.toLocaleString('de-DE', { style: 'currency', currency: selectedCurrency })}
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">{t('totalContributions')}</h3>
                <p className="text-2xl font-bold text-green-600">
                  {result.totalContributions.toLocaleString('de-DE', { style: 'currency', currency: selectedCurrency })}
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-500 mb-1">{t('returns')}</h3>
                <p className="text-2xl font-bold text-purple-600">
                  {result.totalEarnings.toLocaleString('de-DE', { style: 'currency', currency: selectedCurrency })}
                </p>
              </div>
            </div>
            {chartData && (
              <div className="mt-8 p-4 bg-white rounded-lg">
                <Line options={chartOptions} data={chartData} />
              </div>
            )}
            <div className="text-sm text-gray-500 text-center mt-4">
              <Percent className="w-4 h-4 inline-block mr-1" />
              {t('disclaimer')}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function App() {
  const { t } = useLanguage();
  const [value, setValue] = useState<string>('');
  const [fromUnit, setFromUnit] = useState<string>('meter');
  const [toUnit, setToUnit] = useState<string>('kilometer');
  const [result, setResult] = useState<number | null>(null);
  const [exchangeRates, setExchangeRates] = useState<{ [key: string]: number } | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const categories: Category[] = useMemo(() => [
    {
      id: 'length',
      name: t('length'),
      icon: <Ruler className="w-6 h-6" />,
      units: [
        { id: 'meter', name: t('meter') },
        { id: 'kilometer', name: t('kilometer') },
        { id: 'centimeter', name: t('centimeter') },
        { id: 'millimeter', name: t('millimeter') },
        { id: 'mile', name: t('mile') },
        { id: 'foot', name: t('foot') },
        { id: 'inch', name: t('inch') }
      ],
      convert: (value, from, to) => {
        const toMeter: { [key: string]: number } = {
          meter: 1,
          kilometer: 1000,
          centimeter: 0.01,
          millimeter: 0.001,
          mile: 1609.34,
          foot: 0.3048,
          inch: 0.0254
        };
        
        const meters = value * toMeter[from];
        return meters / toMeter[to];
      }
    },
    {
      id: 'temperature',
      name: t('temperature'),
      icon: <Thermometer className="w-6 h-6" />,
      units: [
        { id: 'celsius', name: t('celsius') },
        { id: 'fahrenheit', name: t('fahrenheit') },
        { id: 'kelvin', name: t('kelvin') }
      ],
      convert: (value, from, to) => {
        let celsius = value;
        if (from === 'fahrenheit') {
          celsius = (value - 32) * 5/9;
        } else if (from === 'kelvin') {
          celsius = value - 273.15;
        }
        
        if (to === 'fahrenheit') {
          return celsius * 9/5 + 32;
        } else if (to === 'kelvin') {
          return celsius + 273.15;
        }
        return celsius;
      }
    },
    {
      id: 'weight',
      name: t('weight'),
      icon: <Scale className="w-6 h-6" />,
      units: [
        { id: 'kilogram', name: t('kilogram') },
        { id: 'gram', name: t('gram') },
        { id: 'milligram', name: t('milligram') },
        { id: 'pound', name: t('pound') },
        { id: 'ounce', name: t('ounce') }
      ],
      convert: (value, from, to) => {
        const toGram: { [key: string]: number } = {
          kilogram: 1000,
          gram: 1,
          milligram: 0.001,
          pound: 453.592,
          ounce: 28.3495
        };
        
        const grams = value * toGram[from];
        return grams / toGram[to];
      }
    },
    {
      id: 'time',
      name: t('time'),
      icon: <Clock className="w-6 h-6" />,
      units: [
        { id: 'second', name: t('second') },
        { id: 'minute', name: t('minute') },
        { id: 'hour', name: t('hour') },
        { id: 'day', name: t('day') },
        { id: 'week', name: t('week') }
      ],
      convert: (value, from, to) => {
        const toSeconds: { [key: string]: number } = {
          second: 1,
          minute: 60,
          hour: 3600,
          day: 86400,
          week: 604800
        };
        
        const seconds = value * toSeconds[from];
        return seconds / toSeconds[to];
      }
    },
    {
      id: 'area',
      name: t('area'),
      icon: <Calculator className="w-6 h-6" />,
      units: [
        { id: 'squareMeter', name: t('squareMeter') },
        { id: 'squareKilometer', name: t('squareKilometer') },
        { id: 'hectare', name: t('hectare') },
        { id: 'are', name: t('are') },
        { id: 'squareFoot', name: t('squareFoot') }
      ],
      convert: (value, from, to) => {
        const toSquareMeter: { [key: string]: number } = {
          squareMeter: 1,
          squareKilometer: 1000000,
          hectare: 10000,
          are: 100,
          squareFoot: 0.092903
        };
        
        const squareMeters = value * toSquareMeter[from];
        return squareMeters / toSquareMeter[to];
      }
    },
    {
      id: 'currency',
      name: t('currency'),
      icon: <DollarSign className="w-6 h-6" />,
      units: [
        { id: 'EUR', name: 'EUR' },
        { id: 'USD', name: 'USD' },
        { id: 'GBP', name: 'GBP' },
        { id: 'JPY', name: 'JPY' },
        { id: 'CHF', name: 'CHF' },
        { id: 'AUD', name: 'AUD' },
        { id: 'CAD', name: 'CAD' },
        { id: 'CNY', name: 'CNY' },
        { id: 'INR', name: 'INR' },
        { id: 'NZD', name: 'NZD' },
        { id: 'SGD', name: 'SGD' },
        { id: 'HKD', name: 'HKD' },
        { id: 'RUB', name: 'RUB' },
        { id: 'AED', name: 'AED' }
      ],
      convert: (value, from, to, rates) => {
        if (!rates) return 0;
        
        if (from === 'EUR') {
          return value * rates[to];
        } else if (to === 'EUR') {
          return value / rates[from];
        } else {
          const eurValue = value / rates[from];
          return eurValue * rates[to];
        }
      }
    },
    {
      id: 'volume',
      name: t('volume'),
      icon: <Droplets className="w-6 h-6" />,
      units: [
        { id: 'liter', name: t('liter') },
        { id: 'milliliter', name: t('milliliter') },
        { id: 'cubicMeter', name: t('cubicMeter') },
        { id: 'gallon', name: t('gallon') },
        { id: 'cubicFoot', name: t('cubicFoot') }
      ],
      convert: (value, from, to) => {
        const toLiter: { [key: string]: number } = {
          liter: 1,
          milliliter: 0.001,
          cubicMeter: 1000,
          gallon: 3.78541,
          cubicFoot: 28.3168
        };
        
        const liters = value * toLiter[from];
        return liters / toLiter[to];
      }
    },
    {
      id: 'power',
      name: t('power'),
      icon: <Power className="w-6 h-6" />,
      units: [
        { id: 'watt', name: t('watt') },
        { id: 'kilowatt', name: t('kilowatt') },
        { id: 'horsepower', name: t('horsepower') },
        { id: 'btu', name: t('btu') }
      ],
      convert: (value, from, to) => {
        const toWatt: { [key: string]: number } = {
          watt: 1,
          kilowatt: 1000,
          horsepower: 735.499,
          btu: 0.29307
        };
        
        const watts = value * toWatt[from];
        return watts / toWatt[to];
      }
    }
  ], [t]);

  const [selectedCategory, setSelectedCategory] = useState<Category>(categories[0]);

  useEffect(() => {
    // Update selected category when categories change (due to language change)
    const newCategory = categories.find(c => c.id === selectedCategory.id) || categories[0];
    setSelectedCategory(newCategory);
  }, [categories, selectedCategory.id]);

  useEffect(() => {
    const fetchExchangeRates = async () => {
      if (selectedCategory.id === 'currency') {
        setLoading(true);
        setError(null);
        try {
          const response = await fetch('https://open.er-api.com/v6/latest/EUR');
          const data = await response.json();
          if (data.rates) {
            setExchangeRates(data.rates);
          } else {
            throw new Error('No exchange rate data available');
          }
        } catch (err) {
          setError(t('error'));
          console.error('Error fetching exchange rates:', err);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchExchangeRates();
  }, [selectedCategory.id, t]);

  const handleConvert = () => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue)) {
      const converted = selectedCategory.convert(numValue, fromUnit, toUnit, exchangeRates);
      setResult(Number(converted.toFixed(6)));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">
            {t('title')}
          </h1>
          <LanguageSelector />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => {
                setSelectedCategory(category);
                setFromUnit(category.units[0].id);
                setToUnit(category.units[1].id);
                setResult(null);
              }}
              className={`p-4 rounded-lg flex flex-col items-center justify-center transition-colors ${
                selectedCategory.id === category.id
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-700 hover:bg-blue-50'
              }`}
            >
              {category.icon}
              <span className="mt-2 text-sm font-medium">{category.name}</span>
            </button>
          ))}
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          {loading && (
            <div className="text-center text-gray-600 mb-4">
              {t('loading')}
            </div>
          )}
          
          {error && (
            <div className="text-center text-red-600 mb-4">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('value')}
              </label>
              <input
                type="number"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={t('enterValue')}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('from')}
              </label>
              <select
                value={fromUnit}
                onChange={(e) => setFromUnit(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {selectedCategory.units.map((unit) => (
                  <option key={unit.id} value={unit.id}>
                    {unit.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('to')}
              </label>
              <select
                value={toUnit}
                onChange={(e) => setToUnit(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {selectedCategory.units.map((unit) => (
                  <option key={unit.id} value={unit.id}>
                    {unit.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-6 flex justify-center">
            <button
              onClick={handleConvert}
              disabled={loading || (selectedCategory.id === 'currency' && !exchangeRates)}
              className={`flex items-center px-6 py-3 rounded-lg transition-colors ${
                loading || (selectedCategory.id === 'currency' && !exchangeRates)
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-blue-500 hover:bg-blue-600 text-white'
              }`}
            >
              <ArrowRightLeft className="w-5 h-5 mr-2" />
              {t('convert')}
            </button>
          </div>

          {result !== null && (
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <p className="text-center text-lg">
                <span className="font-medium">{value} {selectedCategory.units.find(u => u.id === fromUnit)?.name}</span>
                {' = '}
                <span className="font-bold text-blue-600">{result} {selectedCategory.units.find(u => u.id === toUnit)?.name}</span>
              </p>
            </div>
          )}

          {selectedCategory.id === 'currency' && exchangeRates && (
            <div className="mt-4 text-center text-sm text-gray-600">
              {t('liveRates')}
            </div>
          )}
        </div>

        <InvestmentCalculator />
      </div>
    </div>
  );
}

export default App;